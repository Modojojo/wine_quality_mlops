from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="wine quality prediction package",
    author="Modojojo",
    packages=find_packages(),
    liscence="MIT"
)
